![](.meta/screenshot_a.png) ![](.meta/screenshot_b.png)

# Grid Micro theme for Pegasus

The default grid theme of Pegasus, optimized for small displays (320x240).

## Installation

[Download](https://github.com/mmatyas/pegasus-theme-grid-micro/archive/master.zip) and extract the theme to your [theme directory](http://pegasus-frontend.org/docs/user-guide/installing-themes). You can then select it in the settings menu of Pegasus.

## License

[![CC-BY-NC-SA](https://i.creativecommons.org/l/by-nc-sa/4.0/88x31.png)](http://creativecommons.org/licenses/by-nc-sa/4.0/)
